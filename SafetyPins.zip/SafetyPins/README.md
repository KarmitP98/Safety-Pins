# Safety-Pins

The brick-and-mortar company Mom&amp;Pop wants to create an onlinebook store. They want these types of Users: Visitors,
Customers, Administrators, and Partners, to interact with the store. 
