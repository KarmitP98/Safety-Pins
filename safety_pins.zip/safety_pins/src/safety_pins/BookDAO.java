package safety_pins;

import bean.BookBean;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BookDAO extends DAO {
	
	public BookDAO() throws ClassNotFoundException {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	public BookBean retrieveBookByID(String bookID) throws SQLException {
		
		String query = "SELECT * FROM Book WHERE bid=" + bookID;
		BookBean bb = null;
		Connection con = this.ds.getConnection();
		PreparedStatement p = con.prepareStatement(query);
		ResultSet r = p.executeQuery();
		
		while (r.next()) {
			
			String bid = r.getString("bid");
			String title = r.getString("title");
			double price = r.getDouble("price");
			String author = r.getString("author");
			
			String category = String.valueOf(r.getString("category"));
			
			String picture = r.getString("picture");
			String description = r.getString("description");
			int quantitySold = r.getInt("sold");
			
			bb = new BookBean(bid, title, price, author, category, picture, description, quantitySold);
		
		}
		r.close();
		p.close();
		con.close();
		
		return bb;
	}
	
	public List<BookBean> retrieveAllBooks() throws SQLException {
		String query = "select * from Book";
		Connection con = this.ds.getConnection();
		PreparedStatement p = con.prepareStatement(query);
		ResultSet r = p.executeQuery();
		ArrayList<BookBean> list = new ArrayList<BookBean>();
		
		
		while (r.next()) {
			
			String bid = r.getString("bid");
			String title = r.getString("title");
			double price = r.getDouble("price");
			String author = r.getString("author");
			
			String category = String.valueOf(r.getString("category"));
			
			String picture = r.getString("picture");
			String description = r.getString("description");
			int quantitySold = r.getInt("sold");
			
			list.add(new BookBean(bid, title, price, author, category, picture, description, quantitySold));
			
		}
		
		r.close();
		p.close();
		con.close();
		
		return list;
		
		
	}
	
	public List<BookBean> retrieveBooksByCategory(String type) throws SQLException {
		String query = "select * from Book where category like '%" + type +"%'";
		Connection con = this.ds.getConnection();
		PreparedStatement p = con.prepareStatement(query);
		ResultSet r = p.executeQuery();
		ArrayList<BookBean> list = new ArrayList<BookBean>();
		
		
		while (r.next()) {
			
			String bid = r.getString("bid");
			String title = r.getString("title");
			double price = r.getDouble("price");
			String author = r.getString("author");
			String category = r.getString("category");
			//BookType category = BookType.valueOf(r.getString("category"));
			
			String picture = r.getString("picture");
			String description = r.getString("description");
			int quantitySold = r.getInt("sold");
			
			list.add(new BookBean(bid, title, price, author, category, picture, description, quantitySold));
			
		}
		
		r.close();
		p.close();
		con.close();
		
		return list;
	}
}