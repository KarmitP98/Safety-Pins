package safety_pins;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class BookDAOTEST {

	DataSource ds;

	public BookDAOTEST() throws ClassNotFoundException{
		try {
			//ds = (DataSource) (new InitialContext()).lookup("jdbc/Db2-PINS_SAFETY");   //Db2-4413");//"java:/comp/env/jdbc/EECS");
			ds = (DataSource) (new InitialContext()).lookup("java:/comp/env/jdbc/EECS");
		} catch (NamingException e) {
			e.printStackTrace();

		}
	}
	 public void readAndPrintTableToConsole() throws SQLException {
		 
			try {
				DataSource ds = (DataSource) (new InitialContext()).lookup("java:/comp/env/jdbc/EECS");
				Connection con = ds.getConnection();
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery("SELECT * FROM BOOK");
				while(rs.next()){
					 String em= rs.getString("BID");
					String fname = rs.getString("TITLE");
					System.out.println("\t" + em+ ",\t" + fname+ "\t ");
					}//end while loop
				 con.close();
				 } catch (NamingException e) {
					 e.printStackTrace();
				 }
		    }

}
