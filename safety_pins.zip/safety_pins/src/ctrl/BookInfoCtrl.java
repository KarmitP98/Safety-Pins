package ctrl;

import java.io.IOException;
import java.io.Writer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.BookBean;
import safety_pins.BookDAO;
import safety_pins.BookDAOTEST;

/**
 * Servlet implementation class BookInfoCtrl
 */
@WebServlet("/BookInfoCtrl")
public class BookInfoCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookInfoCtrl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
      /*
		if (request.getParameter("Report")==null|| request.getParameter("Report").equals("false")) {
			String target = "/Form.jspx";
			request.getRequestDispatcher(target).forward(request, response);
		}
		else {*/
			try {	
				BookDAOTEST sd = new BookDAOTEST();
				sd.readAndPrintTableToConsole();
				//--kyle's code test
				/*Writer resOut = response.getWriter();
				resOut.write("Test1!!!*** \n");
				
				BookDAO sd = new BookDAO();
				BookBean obj = sd.retrieveBookByID("004");
				System.out.println("book name: "+ obj.getTitle());
				*/
			}catch(Exception e) {
				e.printStackTrace();
			}
		//}
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
